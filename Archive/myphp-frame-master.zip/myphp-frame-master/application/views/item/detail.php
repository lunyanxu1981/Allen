ID：<?php echo $item['id'] ?><br />
Name：<?php echo isset($item['item_name']) ? $item['item_name'] : '' ?>

<br />
<br />
<a class="big" href="/item/index">返回</a>