<?php


class HelpController{
    public function HelpInfo(){
        include 'views/helpView.php';
    }
}
