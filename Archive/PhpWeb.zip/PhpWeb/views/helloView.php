<html>
   <head>
      <title>PHP test website</title>
      <?php include("_layout/header.php");?>
   </head>   
   <body>
       <div>            
            URL: <?= $_SERVER['REQUEST_URI']?>
            <br>Database log: <br><?=$person->result?>
        </div>
   </body>
</html>