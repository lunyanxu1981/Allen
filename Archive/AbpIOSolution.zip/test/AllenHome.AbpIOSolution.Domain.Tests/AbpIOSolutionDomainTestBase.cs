﻿namespace AllenHome.AbpIOSolution
{
    public abstract class AbpIOSolutionDomainTestBase : AbpIOSolutionTestBase<AbpIOSolutionDomainTestModule> 
    {

    }
}
