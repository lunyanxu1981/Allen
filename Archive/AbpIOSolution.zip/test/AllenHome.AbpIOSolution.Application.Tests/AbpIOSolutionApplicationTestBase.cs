﻿namespace AllenHome.AbpIOSolution
{
    public abstract class AbpIOSolutionApplicationTestBase : AbpIOSolutionTestBase<AbpIOSolutionApplicationTestModule> 
    {

    }
}
