﻿using Volo.Abp;

namespace AllenHome.AbpIOSolution.EntityFrameworkCore
{
    public abstract class AbpIOSolutionEntityFrameworkCoreTestBase : AbpIOSolutionTestBase<AbpIOSolutionEntityFrameworkCoreTestModule> 
    {

    }
}
