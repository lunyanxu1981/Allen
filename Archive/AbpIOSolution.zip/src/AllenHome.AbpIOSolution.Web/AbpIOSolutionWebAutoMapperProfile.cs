﻿using AutoMapper;

namespace AllenHome.AbpIOSolution.Web
{
    public class AbpIOSolutionWebAutoMapperProfile : Profile
    {
        public AbpIOSolutionWebAutoMapperProfile()
        {
            //Define your AutoMapper configuration here for the Web project.
        }
    }
}
