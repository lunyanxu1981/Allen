﻿namespace AllenHome.AbpIOSolution.Web.Pages
{
    public class IndexModel : AbpIOSolutionPageModel
    {
        public void OnGet()
        {
            
        }
    }
}