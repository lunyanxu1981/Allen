﻿using Volo.Abp.Localization;

namespace AllenHome.AbpIOSolution.Localization
{
    [LocalizationResourceName("AbpIOSolution")]
    public class AbpIOSolutionResource
    {

    }
}