﻿namespace AllenHome.AbpIOSolution
{
    public static class AbpIOSolutionDomainErrorCodes
    {
        /* You can add your business exception error codes here, as constants */
    }
}
