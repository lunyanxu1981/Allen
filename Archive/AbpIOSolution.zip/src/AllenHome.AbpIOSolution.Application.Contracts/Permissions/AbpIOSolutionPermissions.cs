﻿namespace AllenHome.AbpIOSolution.Permissions
{
    public static class AbpIOSolutionPermissions
    {
        public const string GroupName = "AbpIOSolution";

        //Add your own permission names. Example:
        //public const string MyPermission1 = GroupName + ".MyPermission1";
    }
}