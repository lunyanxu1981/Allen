﻿namespace AllenHome.AbpIOSolution.Settings
{
    public static class AbpIOSolutionSettings
    {
        private const string Prefix = "AbpIOSolution";

        //Add your own setting names here. Example:
        //public const string MySetting1 = Prefix + ".MySetting1";
    }
}