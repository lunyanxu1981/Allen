﻿namespace AllenHome.AbpIOSolution
{
    public static class AbpIOSolutionConsts
    {
        public const string DbTablePrefix = "App";

        public const string DbSchema = null;
    }
}
