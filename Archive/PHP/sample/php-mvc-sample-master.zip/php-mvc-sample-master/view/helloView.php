<!--

    This is just a view that defines how the page looks.
    It doesn't do any logic, access the DB, or anything else.

    It is completely dumb.

-->

<h1 style="color: deeppink">
    Hello <?php print $person->name; ?>
</h1>

<p>
    You like everything to be <?php print $person->fav_colour; ?> ;)
</p>
