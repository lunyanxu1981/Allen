﻿using System;
using System.Collections.Generic;
using System.Text;

namespace project.service.ApiModel
{
    public class UploadFileResponse
    {
        public string Url { get; set; }
    }
}
