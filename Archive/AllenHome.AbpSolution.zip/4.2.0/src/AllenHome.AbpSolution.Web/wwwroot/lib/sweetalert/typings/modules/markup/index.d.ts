export * from './modal';
export { default as overlayMarkup } from './overlay';
export * from './icons';
export * from './content';
export * from './buttons';
export declare const iconMarkup: string;
export declare const titleMarkup: string;
export declare const textMarkup: string;
export declare const footerMarkup: string;
