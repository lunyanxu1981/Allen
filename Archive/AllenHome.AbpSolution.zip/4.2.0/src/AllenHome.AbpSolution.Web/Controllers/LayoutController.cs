namespace AllenHome.AbpSolution.Web.Controllers
{
    public class LayoutController : AbpSolutionControllerBase
    {

    }
}