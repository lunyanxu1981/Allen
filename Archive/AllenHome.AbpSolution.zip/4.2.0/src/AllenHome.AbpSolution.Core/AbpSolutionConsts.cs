﻿namespace AllenHome.AbpSolution
{
    public class AbpSolutionConsts
    {
        public const string LocalizationSourceName = "AbpSolution";

        public const string ConnectionStringName = "Default";
    }
}