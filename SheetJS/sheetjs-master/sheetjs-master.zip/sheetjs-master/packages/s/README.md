# s

TypeScript/JavaScript wrapper closely aligned with the OfficeJS Excel API in the
MIT-licensed <https://github.com/OfficeDev/office-js-docs-reference>

The `1.x.x` releases should not be treated as stable.  `0.x.x` releases serve to
preserve the original use of the `S` module.

## License

Please consult the attached LICENSE file for details.  All rights not explicitly
granted by the Apache 2.0 License are reserved by the Original Author.
